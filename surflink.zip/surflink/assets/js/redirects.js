jQuery(document).ready(function ($) {
  function noticeTypeSelector(type) {
    var noticeClass = "";

    switch (type) {
      case "success":
        noticeClass = "notice-success";
        break;
      case "error":
        noticeClass = "notice-error";
        break;
      case "warning":
        noticeClass = "notice-warning";
        break;
      case "info":
        noticeClass = "notice-info";
        break;

      default:
        noticeClass = "notice-info";
    }

    return noticeClass;
  }
  // Helper function to display redirect table notifications
  function showRedirectTableNotification(type, message) {
    $("#surf-sr-redirects-table-notification").html("");
    var noticeClass = noticeTypeSelector(type);
    var notice = $(
      '<div class="notice ' +
        noticeClass +
        ' is-dismissible"><p>' +
        message +
        "</p></div>"
    );
    $("#surf-sr-redirects-table-notification").append(notice);
    // Auto dismiss after 3 seconds
    setTimeout(function () {
      notice.fadeOut("slow");
    }, 5000);
  }

  function showRedirectFormNotification(type, message) {
    $("#surf-sr-redirect-form-notice").html("");
    var noticeClass = noticeTypeSelector(type);
    var notice = $(
      '<div class="notice ' +
        noticeClass +
        ' is-dismissible"><p>' +
        message +
        "</p></div>"
    );
    $("#surf-sr-redirect-form-notice").append(notice);
    // Auto dismiss after 3 seconds
    setTimeout(function () {
      notice.fadeOut("slow");
    }, 5000);
  }

  // sr report fadeout
  $(document).on("click", "#surfl-sr-report-close-btn", function () {
    $("#surfl-report-container").fadeOut("slow");
  });

  // --- Bulk Action Functionality ---

  // "Select all" checkbox to toggle all bulk checkboxes
  $(document).on("change", "#surfl-redirect-3-bulk-select-all", function () {
    $(".surfl-redirect-3-bulk-select").prop("checked", $(this).prop("checked"));
  });

  // Show/hide redirect type dropdown based on bulk action
  $("#surfl-redirect-3-bulk_action").on("change", function () {
    if ($(this).val() === "change_type") {
      $("#surfl-redirect-3-new-type").show();
    } else {
      $("#surfl-redirect-3-new-type").hide();
    }
  });

  // Handle bulk action apply
  $(document).on("click", "#surfl-redirect-3-bulk-action-apply", function (e) {
    e.preventDefault();
    var action = $("#surfl-redirect-3-bulk_action").val();
    if (action === "-1") {
      showRedirectTableNotification(
        "warning",
        "Please select an action to apply."
      );
      return;
    }

    var selectedSources = [];
    $(".surfl-redirect-3-bulk-select:checked").each(function () {
      selectedSources.push($(this).val());
    });

    if (selectedSources.length === 0) {
      showRedirectTableNotification(
        "warning",
        "Please select at least one redirect."
      );
      return;
    }
    if (action === "delete") {
      var selectedSources = [];
      $(".surfl-redirect-3-bulk-select:checked").each(function () {
        selectedSources.push($(this).val());
      });
      if (selectedSources.length === 0) {
        showRedirectTableNotification(
          "warning",
          "Please select at least one redirect to delete."
        );

        return;
      }

      $.post(surflRedirects.ajaxurl, {
        action: "surfl_bulk_delete_redirects_3",
        security: surflRedirects.nonce,
        sources: selectedSources,
      }).done(function (response) {
        if (response.success) {
          // Remove corresponding rows from the table
          $(".surfl-redirect-3-bulk-select:checked").each(function () {
            $(this)
              .closest("tr")
              .fadeOut(300, function () {
                $(this).remove();
              });
          });

          showRedirectTableNotification("success", response.data.message);
        } else {
          showRedirectTableNotification("error", response.data.message);
        }
      });
    } else if (action === "change_type") {
      var newType = $("#surfl-redirect-3-new-type").val();
      $.post(surflRedirects.ajaxurl, {
        action: "surfl_bulk_change_redirect_type_3",
        security: surflRedirects.nonce,
        sources: selectedSources,
        redirect_type: newType,
      }).done(function (response) {
        if (response.success) {
          $(".surfl-redirect-3-bulk-select:checked").each(function () {
            $(this).closest("tr").find("td:eq(4)").text(newType);
          });
          showRedirectTableNotification("success", response.data.message);
        } else {
          showRedirectTableNotification("error", response.data.message);
        }
      });
    }
  });

  /*
   *
   ************* // --- Adding individual redirects ---
   *
   */

  $(document).on("submit", "#surfl-redirect-3-form", function (e) {
    e.preventDefault();
    var source = $("#source").val();
    var target = $("#target").val();
    var redirect_type = $('input[name="redirect_type"]:checked').val();

    console.log(redirect_type);

    $.post(surflRedirects.ajaxurl, {
      action: "surfl_add_redirect_3",
      source: source,
      target: target,
      redirect_type: redirect_type,
      security: surflRedirects.nonce,
    }).done(function (response) {
      if (response.success) {
        // Clear form fields
        $("#source").val("");
        $("#target").val("");
        $('input[name="redirect_type"][value="301"]').prop("checked", true);

        showRedirectFormNotification("success", response.data.message);

        // Add the new redirect to the table including the extra checkbox cell
        var newRow =
          '<tr data-source="' +
          response.data.source +
          '">' +
          '<td><input type="checkbox" class="surfl-redirect-3-bulk-select" value="' +
          response.data.source +
          '"></td>' +
          "<td>" +
          response.data.id +
          "</td>" +
          "<td>" +
          response.data.source +
          "</td>" +
          '<td><a href="' +
          response.data.target +
          '" target="_blank">' +
          response.data.target +
          "</a></td>" +
          "<td>" +
          response.data.redirect_type +
          "</td>" +
          '<td><button class="edit-redirect"><span class="dashicons dashicons-edit"></span></button>' +
          '<button class="delete-redirect"><span class="dashicons dashicons-trash"></span></button>' +
          "</tr>";

        $("#redirect-list").append(newRow);
      } else {
        showRedirectFormNotification("error", response.data.message);
      }
    });
  });

  // --- Deleting individual redirects ---
  $(document).on("click", ".delete-redirect", function () {
    var row = $(this).closest("tr");
    var source = row.data("source");

    $.post(surflRedirects.ajaxurl, {
      action: "surfl_delete_redirect_3",
      security: surflRedirects.nonce,
      source: source,
    }).done(function (response) {
      if (response.success) {
        row.fadeOut(300, function () {
          $(this).remove();
        });
      } else {
        showRedirectTableNotification("error", response.data.message);
      }
    });
  });

  // --- Editing individual redirects ---
  $(document).on("click", ".edit-redirect", function () {
    var row = $(this).closest("tr");
    // Adjust index because of new checkbox column. (ID is at index 1 now)
    var id = row.find("td:eq(1)").text();
    var source = row.find("td:eq(2)").text();
    var target = row.find("td:eq(3)").text();
    var redirect_type = row.find("td:eq(4)").text();

    var existingRow = row.clone(); // Clone row before replacing

    var editRow =
      '<tr data-id="' +
      id +
      '" data-source="' +
      source +
      '">' +
      "<td></td>" + // empty cell for the checkbox column in edit mode
      "<td>" +
      id +
      "</td>" +
      "<td><input type='text' value='" +
      source +
      "'></td>" +
      "<td><input type='text' value='" +
      target.trim() +
      "'></td>" +
      "<td><select>" +
      "<option value='301'" +
      (redirect_type === "301" ? " selected" : "") +
      ">301</option>" +
      "<option value='302'" +
      (redirect_type === "302" ? " selected" : "") +
      ">302</option>" +
      "<option value='307'" +
      (redirect_type === "307" ? " selected" : "") +
      ">307</option>" +
      "</select></td>" +
      '<td><button class="save-redirect"><span class="dashicons dashicons-yes"></span></button>' +
      '<button class="cancel-redirect"><span class="dashicons dashicons-no"></span></button></td>' +
      "</tr>";

    row.replaceWith(editRow);

    // Cancel  individual redirects update ---
    $(document).on("click", ".cancel-redirect", function (e) {
      e.preventDefault();
      $(this).closest("tr").replaceWith(existingRow);
    });

    // --- Updating individual redirects ---

    $(document).on("click", ".save-redirect", function (e) {
      e.preventDefault();

      var row = $(this).closest("tr");
      var id = row.data("id");
      var source = row.find("input:eq(0)").val();
      var target = row.find("input:eq(1)").val();
      var redirect_type = row.find("select").val();

      $.post(surflRedirects.ajaxurl, {
        action: "surfl_update_redirect_3",
        security: surflRedirects.nonce,
        id: id,
        source: source,
        target: target,
        redirect_type: redirect_type,
      }).done(function (response) {
        if (response.success) {
          var newRow =
            '<tr data-id="' +
            response.data.id +
            '" data-source="' +
            response.data.source +
            '">' +
            '<td><input type="checkbox" class="surfl-redirect-3-bulk-select" value="' +
            response.data.source +
            '"></td>' +
            "<td>" +
            response.data.id +
            "</td>" +
            "<td>" +
            response.data.source +
            "</td>" +
            '<td><a href="' +
            response.data.target +
            '" target="_blank">' +
            response.data.target +
            "</a></td>" +
            "<td>" +
            response.data.redirect_type +
            "</td>" +
            '<td><button class="edit-redirect"><span class="dashicons dashicons-edit"></span></button>' +
            '<button class="delete-redirect"><span class="dashicons dashicons-trash"></span></button></td>' +
            "</tr>";

          row.replaceWith(newRow);

          showRedirectTableNotification("success", response.data.message);
        } else {
          showRedirectTableNotification("error", response.data.message);
        }
      });
    });
  });

  // Add BULK Redirect

  // Show bulk form
  $(document).on("click", "#surfl-bulk-redirect-button", function (e) {
    e.preventDefault();
    $("#surfl-bulk-redirect-form").show();
    $("#surfl-redirect-3-form").hide();
    $("#surfl-redirect-3-single-heading").hide();
    $(this).hide();
  });

  // Hide bulk form
  $(document).on("click", "#surfl-cancel-bulk", function (e) {
    e.preventDefault();
    $("#surfl-bulk-redirect-form").hide();
    $("#surfl-redirect-3-form").show();
    $("#surfl-redirect-3-single-heading").show();
    $("#surfl-bulk-redirect-button").show();
  });

  // Handle bulk form submission
  $(document).on("submit", "#surfl-bulk-redirect-form-inner", function (e) {
    e.preventDefault();
    console.log("clicked");
    var sources = $("#surfl-bulk-sources").val().split("\n");
    var target = $("#surfl-bulk-target").val();

    var redirect_type = $(
      'input[name="surfl_bulk_redirect_type"]:checked'
    ).val();

    $.post(surflRedirects.ajaxurl, {
      action: "surfl_add_bulk_redirects_3",
      security: surflRedirects.nonce,
      sources: sources,
      target: target,
      redirect_type: redirect_type,
    }).done(function (response) {
      if (response.success) {
        console.log(response);
        // Clear form fields
        $("#surfl-bulk-sources").val("");
        $("#surfl-bulk-target").val("");
        $('input[name="surfl_bulk_redirect_type"][value="301"]').prop(
          "checked",
          true
        );
        // Show success message
        showRedirectFormNotification("success", response.data.message);
        // Refresh the redirect list
        location.reload();
      } else {
        showRedirectFormNotification("error", response.data.message);
      }
    });
  });
});
