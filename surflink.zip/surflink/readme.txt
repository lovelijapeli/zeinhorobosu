=== SurfLink ===
Contributors: surflabtech, raiyanmrf
Tags: search replace, update urls, url redirect
Requires at least: 5.6
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://opensource.org/licenses/GPL-3.0

A comprehensive WordPress plugin for URL management, database operations,Backup and Restore, redirect handling and login management.

== Description ==

SurfLink is a powerful WordPress plugin that helps you manage your website's URLs, perform database operations, and handle redirects efficiently. Whether you're moving your site to a new domain, updating URLs, or managing redirects, this plugin provides all the tools you need.

**Database Operations**
* Serialization support for all tables
* The ability to select specific tables
* The ability to select categories (post,attachments etc.) for easy url replacement
* The ability to run a "dry run" to see how many fields will be updated
* No server requirements aside from a running installation of WordPress
* WordPress Multisite support

**Redirect Management**
* Add single or multiple redirects with ease
* Support for different redirect types:
  * 301 Permanent Move
  * 302 Temporary Move
  * 307 Temporary Redirect
* Comprehensive redirect management:
  * Edit existing redirects
  * Delete individual or bulk redirects
  * Change redirect types
  * Bulk redirect type modification
  * Import/Export redirects


**Supported Languages**

* English

== Installation ==

Install SurfLink like you would install any other WordPress plugin.

Dashboard Method:

1. Login to your WordPress admin and go to Plugins -> Add New
2. Type "SurfLink" in the search bar and select this plugin
3. Click "Install", and then "Activate Plugin"


Upload Method:

1. Unzip the plugin and upload the "slt-surf-link" folder to your 'wp-content/plugins' directory
2. Activate the plugin through the Plugins menu in WordPress

== Frequently Asked Questions ==

= Using SurfLink =

Once activated, SurfLink will add a page under the "SurfLink" menu page in your WordPress admin.

= Can I damage my site with this plugin? =

Yes! Entering a wrong search or replace string could damage your database. Because of this, it is always adviseable to have a backup of your database before using this plugin.

= How does this work on WordPress Multisite?

= You can go to the dashboard of any subsite to run a search/replace on just the tables for that subsite.

= How can I use this plugin when changing URLs? =

If you're moving your site from one server to another and changing the URL of your WordPress installation, the approach below allows you to do so easily without affecting the old site:

1. Backup the database on your current site
2. Install the database on your new host
3. On the new host, define the new site URL in the `wp-config.php` file, as shown [here](http://codex.wordpress.org/Changing_The_Site_URL#Edit_wp-config.php)
4. Log in at your new admin URL and run SurfLink on the old site URL for the new site URL
5. Delete the site_url constant you added to `wp-config.php`. You may also need to regenerate your .htaccess by going to Settings -> Permalinks and saving the settings.

More information on moving WordPress can be found [here](http://codex.wordpress.org/Moving_WordPress).

== Changelog ==

= 1.0 =
* Initial release

