<?php
/**
 * Plugin Name: SurfLink
 * Plugin URI: https://surflabtech.com 
 * Description: A comprehensive WordPress plugin for URL management, database operations, and redirect handling.
 * Author: Surf Lab Tech
 * Version: 1.0.0
 * Text Domain: surflink
 * License: GPL-3.0-or-later
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 */

// Prevent direct access.
if (!defined('WPINC')) {
    die;
}

// Autoload plugin classes.
require_once plugin_dir_path(__FILE__) . 'includes/class-surf-link-loader.php';

/**
 * Initialize the plugin and set up all necessary constants and core functionalities.
 * 
 * This function is hooked to 'plugins_loaded' action and:
 * - Defines plugin constants for paths, URLs, and version
 * - Sets up multisite detection and related constants
 * - Initializes the main loader class which bootstraps the plugin
 * 
 * @since 1.0.0
 * @return void
 */
function surfl_plugin_initialize()
{
    // Define plugin constants for easy reference throughout the plugin
    define('SURFL_FILE', __FILE__);
    define('SURFL_PATH', plugin_dir_path(__FILE__));
    define('SURFL_URL', plugin_dir_url(__FILE__));
    define('SURFL_VERSION', '1.0.0');

    // Set up multisite detection and related constants
    if (is_multisite()) {
        define('SURFL_IS_MULTISITE', true);

        if (is_main_site()) {
            define('SURFL_IS_MAIN_SITE', true);
        } else {
            define('SURFL_IS_MAIN_SITE', false);
            define('SURFL_CURRENT_BLOG_ID', get_current_blog_id());
        }
    } else {
        define('SURFL_IS_MULTISITE', false);
    }

    // Load and run the loader class.
    $plugin = new SURFL_Loader();
    $plugin->run();
}

// Hook to WordPress plugins_loaded action to initialize the plugin
add_action('plugins_loaded', 'surfl_plugin_initialize');
