<?php

/**
 * Class SURFL_Redirects
 * 
 * Handles URL redirects functionality for WordPress sites.
 * Provides methods for managing redirects including adding, updating, deleting,
 * and handling redirects in real-time.
 */
if (!defined('ABSPATH')) {
    exit;
}
class SURFL_Redirects
{
    /**
     * @var string Database table name for redirects
     */
    public string $table_redirects;

    /**
     * Constructor for SURFL_Redirects class
     * 
     * Initializes the redirects functionality by:
     * - Installing required database tables
     * - Setting up AJAX handlers
     * - Initializing redirect handling
     */
    public function __construct()
    {
        $this->install();

        add_action('wp_ajax_surfl_add_redirect_3', [$this, 'ajax_add_redirect']);
        add_action('wp_ajax_surfl_add_bulk_redirects_3', [$this, 'ajax_add_bulk_redirects']);
        add_action('wp_ajax_surfl_delete_redirect_3', [$this, 'ajax_delete_redirect']);
        add_action('wp_ajax_surfl_update_redirect_3', [$this, 'ajax_update_redirect']);
        add_action('wp_ajax_surfl_bulk_delete_redirects_3', [$this, 'ajax_bulk_delete_redirects']);
        add_action('wp_ajax_surfl_bulk_change_redirect_type_3', [$this, 'ajax_bulk_change_redirect_type']);

        add_action('template_redirect', [$this, 'handle_redirects']);

        global $wpdb;
        $this->table_redirects = $wpdb->prefix . 'surfl_table_redirects';
    }

    /**
     * Installs the required database table for redirects
     * 
     * Creates the redirects table if it doesn't exist with the following structure:
     * - id (INT, AUTO_INCREMENT, PRIMARY KEY)
     * - source_url (VARCHAR(255))
     * - target_url (VARCHAR(255))
     * - redirect_type (ENUM('301','302','307'))
     * 
     * @since 1.0.0
     * @return void
     */
    public function install(): void
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'surfl_table_redirects';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
        id INT AUTO_INCREMENT PRIMARY KEY,
        source_url VARCHAR(255) NOT NULL,
        target_url VARCHAR(255) NOT NULL,
        redirect_type ENUM('301','302','307') NOT NULL
    ) $charset_collate;";

            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);
        }
    }

    /**
     * Checks if a given URL is external to the current site
     * 
     * @since 1.0.0
     * @param string $url The URL to check
     * @return bool True if the URL is external, false if internal
     */
    public function is_external_url(string $url): bool
    {
        // Check if the URL is a full URL (starts with http:// or https://)
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            // Parse the URL into components
            $parsed_url = wp_parse_url($url);
            // Get the site's host
            $parsed_home_url = wp_parse_url(home_url());
            $site_host = isset($parsed_home_url['host']) ? $parsed_home_url['host'] : '';

            // Compare the host with the site's domain
            if (isset($parsed_url['host'])) {
                // If it's https:// but not your site's domain, it's external
                if (($parsed_url['scheme'] === 'https' || $parsed_url['scheme'] === 'http') && $parsed_url['host'] !== $site_host) {
                    return true; // External URL
                }
                // If it's doesn't match the domain, consider it internal
                return false; // Internal URL
            }
        }

        // If it's not a full URL or it's a relative URL, assume it's internal
        return false; // Internal URL
    }

    /**
     * Renders the redirects management page
     * 
     * Displays a paginated list of redirects with options to manage them
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_redirect_page(): void
    {
        global $wpdb;

        $per_page = 20;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $offset = ($current_page - 1) * $per_page;
        $table_redirects = $this->table_redirects;
        $redirects = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_redirects ORDER BY id ASC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        ));

        $total = $wpdb->get_var("SELECT COUNT(id) FROM $table_redirects");

        require SURFL_PATH . 'templates/surfl-redirect-html.php';
    }

    /**
     * Handles AJAX request to add a single redirect
     * 
     * @since 1.0.0
     * @return void
     * @throws \Exception If unauthorized or invalid data
     */
    public function ajax_add_redirect(): void
    {
        check_ajax_referer('surfl_redirect_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized action', 'surflink')]);
        }
        global $wpdb;
        $source_raw = isset($_POST['source']) ? sanitize_text_field($_POST['source']) : '';
        $source = $this->normalize_path($source_raw);

        $target = isset($_POST['target']) ? sanitize_text_field($_POST['target']) : '';

        if (empty($source)) {
            wp_send_json_error(['message' => __('Fields cannot be empty', 'surflink')]);
        }
        if (empty($target) || $target === '/') {
            $target = home_url();
        } else if ($this->is_external_url($target)) {
            $target = sanitize_url($target);
        } else {
            $target = $this->normalize_path($target);

            $check_target = home_url() . '/' . $target;

            // Attempt a HEAD request to check if the target URL exists.
            $response = wp_remote_head($check_target);

            // Fallback: If the HEAD request fails, try using a GET request.
            if (is_wp_error($response) || !isset($response['response']['code'])) {
                $response = wp_remote_get($check_target, ['timeout' => 5]);
            }

            // If the GET request fails or returns a 404, the target is considered invalid.
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) == 404) {
                wp_send_json_error(['message' => __('Target is not a valid URL', 'surflink')]);
            }
        }

        $redirect_type = isset($_POST['redirect_type']) ? sanitize_text_field($_POST['redirect_type']) : '301';


        if ($target == $source) {
            wp_send_json_error(['message' => __('Target cannot be the same as the source', 'surflink')]);
        }

        if ($wpdb->get_var("SHOW TABLES LIKE '{$this->table_redirects}'") != $this->table_redirects) {
            wp_send_json_error(['message' => __('Database table not found', 'surflink')]);
        }

        $redirects = $this->get_redirects();

        foreach ($redirects as $redirect) {
            if ($source == $redirect->source_url) {
                wp_send_json_error(['message' => __('Redirect already exists', 'surflink')]);
            }
        }

        $count = $wpdb->get_var("SELECT COUNT(*) FROM $this->table_redirects");

        if ($count == 0) {
            $wpdb->query("ALTER TABLE $this->table_redirects AUTO_INCREMENT = 1");
        }

        $wpdb->insert(
            $this->table_redirects,
            [
                'source_url' => $source,
                'target_url' => $target,
                'redirect_type' => $redirect_type,
            ]
        );

        if ($wpdb->insert_id) {
            wp_send_json_success(
                [
                    'id' => $wpdb->insert_id,
                    'message' => __('Redirect added successfully', 'surflink'),
                    'source' => $source,
                    'target' => $target,
                    'redirect_type' => $redirect_type
                ]
            );
        } else {
            wp_send_json_error(['message' => __('Failed to add redirect', 'surflink')]);
        }
    }

    /**
     * Handles AJAX request to add multiple redirects
     * 
     * @since 1.0.0
     * @return void
     * @throws \Exception If unauthorized or invalid data
     */
    public function ajax_add_bulk_redirects(): void
    {
        check_ajax_referer('surfl_redirect_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized action', 'surflink')]);
        }

        global $wpdb;
        $sources = is_array($_POST['sources']) ? array_map('sanitize_text_field', $_POST['sources']) : [];
        $target = isset($_POST['target']) ? sanitize_text_field($_POST['target']) : '';
        $redirect_type = isset($_POST['redirect_type']) ? sanitize_text_field($_POST['redirect_type']) : '301';


        // Add this after getting $redirect_type
        if (!in_array($redirect_type, ['301', '302', '307'])) {
            wp_send_json_error(['message' => __('Invalid redirect type', 'surflink')]);
        }

        // Validate target
        if (empty($target) || $target === '/') {
            $target = home_url();
        } elseif ($this->is_external_url($target)) {
            $target = sanitize_url($target);
        } else {
            $target = $this->normalize_path($target);
            $check_target = home_url() . '/' . $target;
            $response = wp_remote_head($check_target);

            if (is_wp_error($response)) {
                $response = wp_remote_get($check_target, ['timeout' => 5]);
            }

            if (is_wp_error($response)) {
                wp_send_json_error(['message' => __('Invalid target URL', 'surflink')]);
            }
        }

        $added = 0;
        $errors = [];
        $existing_sources = $wpdb->get_col("SELECT source_url FROM {$this->table_redirects}");

        foreach ($sources as $source) {
            $source = $this->normalize_path(trim($source));
            if (empty($source))
                continue;

            // Validate source
            if (in_array($source, $existing_sources)) {
                // translators: %s is the source URL that already exists.
                $errors[] = sprintf(__('Source %s already exists', 'surflink'), $source);
                continue;
            }

            $result = $wpdb->insert(
                $this->table_redirects,
                [
                    'source_url' => $source,
                    'target_url' => $target,
                    'redirect_type' => $redirect_type
                ]
            );

            if ($result) {
                $added++;
                $existing_sources[] = $source;
            } else {
                // translators: %s is the source URL that failed to be added.
                $errors[] = sprintf(__('Failed to add %s', 'surflink'), $source);
            }
        }

        if ($added > 0) {
            // translators: %d is the number of redirects that were successfully added.
            $message = sprintf(_n('%d redirect added', '%d redirects added', $added, 'surflink'), $added);
            if (!empty($errors)) {
                $message .= '<br>' . implode('<br>', $errors);
            }
            wp_send_json_success(['message' => $message]);
        } else {
            wp_send_json_error(['message' => implode('<br>', $errors)]);
        }
    }

    /**
     * Handles AJAX request to delete a redirect
     * 
     * @since 1.0.0
     * @return void
     * @throws \Exception If unauthorized or redirect not found
     */
    public function ajax_delete_redirect(): void
    {
        check_ajax_referer('surfl_redirect_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized action', 'surflink')]);
        }

        global $wpdb;
        $source = sanitize_text_field($_POST['source']);
        $redirects = $this->get_redirects();

        foreach ($redirects as $redirect) {
            if ($source == $redirect->source_url) {
                $wpdb->delete($this->table_redirects, ['id' => $redirect->id]);
                wp_send_json_success(['message' => __('Redirect deleted successfully', 'surflink')]);
                exit;
            }
        }

        wp_send_json_error(['message' => __('Redirect not found', 'surflink')]);
    }

    /**
     * Handles incoming requests and performs redirects if needed
     * 
     * @since 1.0.0
     * @return void
     */
    public function handle_redirects(): void
    {
        global $wpdb;
        $request_path = $this->get_current_path();
        $request_path = $this->normalize_path($request_path);
        $redirects = $wpdb->get_results("SELECT * FROM {$this->table_redirects}");

        foreach ($redirects as $redirect) {
            if ($request_path == $redirect->source_url) {
                wp_redirect(esc_url_raw($redirect->target_url), $redirect->redirect_type);
                exit;
            }
        }
    }

    /**
     * Handles AJAX request to update a redirect
     * 
     * @since 1.0.0
     * @return void
     * @throws \Exception If unauthorized or redirect not found
     */
    public function ajax_update_redirect(): void
    {
        check_ajax_referer('surfl_redirect_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized action', 'surflink')]);
        }
        $source = isset($_POST['source']) ? $this->normalize_path(sanitize_text_field($_POST['source'])) : '';

        $target = isset($_POST['target']) ? sanitize_text_field($_POST['target']) : '';
        $redirect_type = isset($_POST['redirect_type']) ? sanitize_text_field($_POST['redirect_type']) : '301';

        if (empty($source) || empty($redirect_type)) {
            wp_send_json_error(['message' => __('Fields cannot be empty', 'surflink')]);
        }
        if (empty($target) || $target === '/') {
            $target = home_url();
        } elseif ($this->is_external_url($target)) {
            $target = sanitize_url($target);
        } else {
            $target = $this->normalize_path($target);
            $check_target = home_url() . '/' . $target;
            $response = wp_remote_head($check_target);

            if (is_wp_error($response)) {
                $response = wp_remote_get($check_target, ['timeout' => 5]);
            }

            if (is_wp_error($response)) {
                wp_send_json_error(['message' => __('Invalid target URL', 'surflink')]);
            }
        }
        global $wpdb;
        $redirects = $this->get_redirects();

        foreach ($redirects as $redirect) {
            if ($source == $redirect->source_url) {
                $wpdb->update($this->table_redirects, ['target_url' => $target, 'redirect_type' => $redirect_type], ['id' => $redirect->id]);
                wp_send_json_success([
                    'message' => __('Redirect updated successfully', 'surflink'),
                    'id' => $redirect->id,
                    'source' => $source,
                    'target' => $target,
                    'redirect_type' => $redirect_type
                ]);
                exit;
            }
        }

        wp_send_json_error(['message' => __('Redirect not found', 'surflink')]);
    }

    /**
     * Retrieves all redirects from the database
     * 
     * @since 1.0.0
     * @return array Array of redirect objects
     */
    public function get_redirects(): array
    {
        //return get_option($this->redirect_option, []);
        global $wpdb;
        $redirects = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table_redirects} WHERE 1 = %d", 1)
        );

        return $redirects;
    }

    /**
     * Normalizes a URL path by removing unnecessary elements
     * 
     * @since 1.0.0
     * @param string $url The URL to normalize
     * @return string Normalized URL path
     */
    public function normalize_path($url)
    {
        $parsed = parse_url($url);
        $path = isset($parsed['path']) ? $parsed['path'] : '';
        $query = isset($parsed['query']) ? '?' . $parsed['query'] : '';
        $path = str_replace('__trashed', '', $path);
        // Determine if it's a file based on extension
        $is_file = preg_match('/\.\w+$/', $path);

        // Remove trailing slash for files (e.g., .js, .css)
        if ($is_file) {
            $path = untrailingslashit($path);
        }

        // Ensure leading slash
        if ($path !== '' && $path[0] !== '/') {
            $path = '/' . $path;
        }

        // Ensure trailing slash (only if not a file)
        if (!$is_file && substr($path, -1) !== '/') {
            $path .= '/';
        }
        return $path . $query;
    }

    /**
     * Gets the current request path
     * 
     * @since 1.0.0
     * @return string Current request path
     */
    public function get_current_path(): string
    {
        $uri = isset($_SERVER['REQUEST_URI']) ? sanitize_url($_SERVER['REQUEST_URI']) : '';
        return $this->normalize_path($uri);
    }

    /**
     * Retrieves paginated redirects
     * 
     * @since 1.0.0
     * @param int $page Page number
     * @param int $per_page Items per page
     * @return array Array of redirect objects
     */
    public function get_redirects_paginated(int $page = 1, int $per_page = 10): array
    {
        global $wpdb;
        $offset = ($page - 1) * $per_page;
        $redirects = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$this->table_redirects} LIMIT %d OFFSET %d", $per_page, $offset)
        );
        return $redirects;
    }

    /**
     * Gets the total count of redirects
     * 
     * @since 1.0.0
     * @return int Number of redirects
     */
    public function get_redirects_count(): int
    {
        global $wpdb;
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_redirects}");
    }

    /**
     * Handles AJAX request to delete multiple redirects
     * 
     * @since 1.0.0
     * @return void
     * @throws \Exception If unauthorized or invalid data
     */
    public function ajax_bulk_delete_redirects(): void
    {
        check_ajax_referer('surfl_redirect_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized action', 'surflink')]);
        }

        if (!isset($_POST['sources']) || !is_array($_POST['sources']) || empty($_POST['sources'])) {
            wp_send_json_error(['message' => __('No redirects selected for deletion', 'surflink')]);
        }

        global $wpdb;
        // Sanitize every source received
        $sources = array_map('sanitize_text_field', $_POST['sources']);


        // Use the spread operator to pass the sources array as individual parameters
        $sql = $wpdb->prepare(
            "DELETE FROM {$this->table_redirects} WHERE source_url IN (" . implode(',', array_fill(0, count($sources), '%s')) . ")",
            ...$sources
        );
        $result = $wpdb->query($sql);

        if ($result !== false) {
            wp_send_json_success(['message' => __('Selected redirects deleted successfully', 'surflink')]);
        } else {
            wp_send_json_error(['message' => __('Failed to delete selected redirects', 'surflink')]);
        }
    }

    /**
     * Handles AJAX request to change redirect type for multiple redirects
     * 
     * @since 1.0.0
     * @return void
     * @throws \Exception If unauthorized or invalid data
     */
    public function ajax_bulk_change_redirect_type(): void
    {
        check_ajax_referer('surfl_redirect_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized action', 'surflink')]);
        }

        $sources = isset($_POST['sources']) ? array_map('sanitize_text_field', $_POST['sources']) : [];

        $redirect_type = isset($_POST['redirect_type']) ? sanitize_text_field($_POST['redirect_type']) : '';

        if (!in_array($redirect_type, ['301', '302', '307'])) {
            wp_send_json_error(['message' => __('Invalid redirect type', 'surflink')]);
        }

        if (empty($sources)) {
            wp_send_json_error(['message' => __('No redirects selected', 'surflink')]);
        }

        global $wpdb;
        $placeholders = implode(',', array_fill(0, count($sources), '%s'));
        $query = $wpdb->prepare(
            "UPDATE {$this->table_redirects} SET redirect_type = %s WHERE source_url IN ($placeholders)",
            array_merge([$redirect_type], $sources)
        );
        $result = $wpdb->query($query);

        if ($result === false) {
            wp_send_json_error(['message' => __('Failed to update redirects', 'surflink')]);
        } elseif ($result === 0) {
            wp_send_json_error(['message' => __('No redirects were updated', 'surflink')]);
        } else {
            wp_send_json_success([

                'message' => sprintf(
                    // translators: %s is the number of redirects that were updated.
                    _n('%d redirect updated.', '%d redirects updated.', $result, 'surflink'),
                    $result
                )
            ]);
        }
    }
}