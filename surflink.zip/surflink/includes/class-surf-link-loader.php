<?php

/**
 * The main loader class for the SurfLink plugin.
 * 
 * This class is responsible for initializing the plugin, loading dependencies,
 * setting up admin pages, and registering all necessary hooks and filters.
 * It serves as the central coordinator for all plugin functionalities.
 * 
 * @since 1.0.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class SURFL_Loader
{
    /**
     * Instance of the search and replace functionality class.
     *
     * @since 1.0.0
     * @var SURFL_HyperDBReplace
     */
    public $surf_link_sr;

    public $surf_link_redirect;

    /**
     * Initialize the loader class.
     * 
     * Sets up class properties, loads dependencies, and registers hooks.
     * 
     * @since 1.0.0
     */
    public function __construct()
    {
        // Include other plugin files.
        $this->load_dependencies();

        // Hook to enqueue assets.
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        $this->surf_link_redirect = new SURFL_Redirects();
        $this->surf_link_sr = new SURFL_HyperDBReplace();
    }

    /**
     * Load required dependencies for the plugin.
     * 
     * Includes all necessary PHP files for the plugin's functionality.
     * 
     * @since 1.0.0
     */
    public function load_dependencies()
    {
        require_once SURFL_PATH . 'includes/class-surf-link-sr.php';
        require_once SURFL_PATH . 'includes/class-surf-link-redirects.php';
    }

    /**
     * Register and enqueue admin-specific styles and scripts.
     * 
     * @since 1.0.0
     */
    public function enqueue_assets()
    {
        if (!defined('SURFL_PATH')) {
            return;
        }


        wp_enqueue_style(
            'surfl-admin-style',
            SURFL_URL . 'assets/css/surf-link.css',
            [],
            '1.0'
        );

        wp_enqueue_script('surfl-redirects', SURFL_URL . 'assets/js/redirects.js', ['jquery'], null, true);
        wp_localize_script('surfl-redirects', 'surflRedirects', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('surfl_redirect_nonce')
        ]);
    }

    /**
     * Register the admin menu and submenu pages.
     * 
     * Sets up the WordPress admin menu structure for the plugin, including
     * the main menu and all submenu pages.
     * 
     * @since 1.0.0
     */
    public function add_admin_menu()
    {
        add_menu_page(
            "SurfLink",
            'SurfLink',
            'manage_options', // Capability.
            'slt-surf-link',
            [$this, 'display_sr_page'],
            SURFL_URL . 'assets/icon_logo_sm.png', // Icon URL.


        );

        // Submenu for Search & Replace
        add_submenu_page(
            'slt-surf-link', // Parent slug.
            'Search & Replace',
            'Search & Replace',
            'manage_options', // Capability.
            'surf-link-sr-page', // Menu slug.
            [$this, 'display_sr_page'] // Callback.
        );

        // Submenu for Redirects
        add_submenu_page(
            'slt-surf-link', // Parent slug.
            'Redirects',
            'Redirects',
            'manage_options', // Capability.
            'surf-link-redirects-page', // Menu slug.
            [$this, 'display_redirect_page'] // Callback.
        );

        // Remove the default submenu item created by add_menu_page
        remove_submenu_page('slt-surf-link', 'slt-surf-link');
    }

    /**
     * Display the search and replace admin page.
     * 
     * Renders the main interface for the search and replace functionality,
     * including tab navigation and the appropriate content based on the active tab.
     * 
     * @since 1.0.0
     */
    public function display_sr_page()
    {
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'surf-link-sr-tab';

        echo '<div class="surfl-container">';
        require_once SURFL_PATH . "templates/surf-link-nav.php";

        echo '<nav class="surfl-second-navs">';
        echo '<a href="?page=surf-link-sr-page&tab=surf-link-sr-tab" class="surfl-second-nav  ' . ($active_tab === 'surf-link-sr-tab' ? 'surfl-second-nav-active' : '') . '">Search&replace</a>';
        echo '<a href="?page=surf-link-sr-page&tab=surf-link-eurl-tab" class="surfl-second-nav  ' . ($active_tab === 'surf-link-eurl-tab' ? 'surfl-second-nav-active' : '') . '">URL Updater</a>';
        echo '</nav>';
        echo '</div>';
        if ($active_tab === 'surf-link-sr-tab') {
            set_transient('surfl_sr_active_tab', $active_tab, 60 * 60);
            $this->surf_link_sr->render_ui();
        } else if ($active_tab === 'surf-link-eurl-tab') {
            set_transient('surfl_sr_active_tab', $active_tab, 60 * 60);
            $this->surf_link_sr->render_url_replace_ui();
        }
    }

    /**
     * Display the redirect page.
     * 
     * Renders the main interface for the redirect functionality,
     * including tab navigation and the appropriate content based on the active tab.
     * 
     * @since 1.0.0
     */
    public function display_redirect_page()
    {


        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'surf-link-redirect-tab';
        echo '<div class="surfl-container">';
        require_once SURFL_PATH . "templates/surf-link-nav.php";


        echo '<nav>';
        echo '<a href="?page=surf-link-redirects-page&tab=surf-link-redirect-tab" class="surfl-second-nav ' . ($active_tab === 'surf-link-redirect-tab' ? 'surfl-second-nav-active' : '') . '">Redirect</a>';

        echo '</nav>';
        echo '</div>';

        if ($active_tab === 'surf-link-redirect-tab') {

            $this->surf_link_redirect->render_redirect_page();
        }
    }

    /**
     * Gets the plugin logo HTML, either as a WordPress attachment or fallback to direct image
     * 
     * @return string HTML for the logo
     */
    public function get_plugin_logo_html()
    {
        $logo_url = SURFL_URL . 'assets/icon_logo_black.png';

        // Try to find the image in the media library
        $logo_id = attachment_url_to_postid($logo_url);

        if ($logo_id) {
            // Image exists in media library
            return wp_get_attachment_image($logo_id, 'full', false, [
                'class' => 'surfl-logo-image',
                'alt' => esc_attr__('Surf Link Logo', 'surflink')
            ]);
        }

        // Fallback for when image isn't in media library
        return sprintf(
            '<img class="surfl-logo-image" src="%s" alt="%s" />',
            esc_url($logo_url),
            esc_attr__('Surf Link Logo', 'surflink')
        );
    }
    /**
     * Run the plugin.
     * 
     * The main function to initialize all hooks and start the plugin execution.
     * 
     * @since 1.0.0
     */
    public function run()
    {
        // Hook to add admin menu.
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }
}


