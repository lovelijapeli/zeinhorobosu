<?php
if (!defined('ABSPATH')) {
    exit;
} ?>


<h1 class="surfl-logo">
    <?php echo wp_kses_post($this->get_plugin_logo_html()); ?>
    <?php echo esc_html__('urf', 'surflink'); ?>
    <span class="surfl-logo-link"><?php echo esc_html__('Link', 'surflink'); ?></span>
</h1>


<nav class="surfl-nav-tabs">
    <a href="?page=surf-link-sr-page"
        class="surfl-nav-tab <?php echo ($active_tab === 'surf-link-sr-tab' ? 'surfl-nav-tab-active' : ''); ?>">
        <?php esc_html_e('Search & Replace', 'surflink'); ?>
    </a>
    <a href="?page=surf-link-redirects-page"
        class="surfl-nav-tab <?php echo ($active_tab === 'surf-link-redirect-tab' ? 'surfl-nav-tab-active' : ''); ?>">
        <?php esc_html_e('Redirects', 'surflink'); ?>
    </a>
</nav>