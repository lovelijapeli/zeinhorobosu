<?php
if (!defined('ABSPATH')) {
    exit;
} ?>


<div>
    <div class="wrap">
        <div class="surfl-sr-warning-box">
            <h3 class="surfl-sr-warning-heading">
                <?php esc_html_e('⚠️ WE RECOMMEND THAT YOU BACKUP YOUR DATABASE FIRST.', 'surflink'); ?>
            </h3>
        </div>

        <?php
        // Check for at least one non-empty error or success message.
        $has_message = false;
        if (!empty($this->reports['errors'])) {
            foreach ($this->reports['errors'] as $error) {
                if (trim($error) !== '') {
                    $has_message = true;
                    break;
                }
            }
        }
        if (!$has_message && !empty($this->reports['success'])) {
            foreach ($this->reports['success'] as $message) {
                if (trim($message) !== '') {
                    $has_message = true;
                    break;
                }
            }
        }
        ?>

        <?php if ($has_message): ?>
            <div class="surfl-notice">
                <?php if (!empty($this->reports['errors'])): ?>
                    <div class="notice notice-error is-dismissible">
                        <?php foreach ($this->reports['errors'] as $error): ?>
                            <?php if (trim($error) !== ''): ?>
                                <p><?php echo esc_html($error); ?></p>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($this->reports['success'])): ?>
                    <div class="notice notice-success is-dismissible">
                        <?php foreach ($this->reports['success'] as $message): ?>
                            <?php if (trim($message) !== ''): ?>
                                <p><?php echo esc_html($message); ?></p>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php
        $has_search_been_run = isset($_POST['process']);

        if ($has_search_been_run) {
            $hasMatches = false;
            if (!empty($this->reports['details'])) {
                foreach ($this->reports['details'] as $table => $details) {

                    $occurrences = 0;
                    if (!empty($details['columns']) && is_array($details['columns'])) {
                        foreach ($details['columns'] as $col => $data) {

                            $occurrences += isset($data['occurrences']) ? $data['occurrences'] : 0;
                        }
                    }
                    if ($occurrences > 0) {
                        $hasMatches = true;
                        break;
                    }
                }
            }
            ?>

            <?php if ($hasMatches): ?>
                <div id="surfl-report-container">
                    <button id="surfl-sr-report-close-btn" class="surfl-close-btn">X</button>
                    <table id="surfl-sr-report" class="wp-list-table widefat striped surfl-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Table', 'surflink'); ?></th>
                                <th><?php esc_html_e('Rows Scanned', 'surflink'); ?></th>
                                <th><?php esc_html_e('Time Taken (s)', 'surflink'); ?></th>
                                <th>
                                    <?php echo !empty($this->reports['dry_run'])
                                        ? esc_html__('Potential Occurrences to Replace', 'surflink')
                                        : esc_html__('Occurrences Replaced', 'surflink'); ?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($this->reports['details'] as $table => $details):
                                $rows_scanned = isset($details['rows_scanned']) ? $details['rows_scanned'] : 0;
                                $time_taken = isset($details['time']) ? $details['time'] : 0;
                                $occurrences = 0;
                                if (!empty($details['columns']) && is_array($details['columns'])) {
                                    foreach ($details['columns'] as $col => $data) {

                                        $occurrences += isset($data['occurrences']) ? $data['occurrences'] : 0;
                                    }
                                }
                                if ($occurrences === 0) {
                                    continue;
                                }
                                ?>
                                <tr>
                                    <td><?php echo esc_html($table); ?></td>
                                    <td><?php echo esc_html($rows_scanned); ?></td>
                                    <td><?php echo number_format($time_taken, 4); ?></td>
                                    <td><?php echo esc_html($occurrences); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>


            <?php else: ?>
                <div class="notice notice-info is-dismissible">
                    <p><?php esc_html_e('No matches found.', 'surflink'); ?></p>
                </div>
            <?php endif; ?>
        <?php } ?>