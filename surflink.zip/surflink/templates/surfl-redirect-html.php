<?php
if (!defined('ABSPATH')) {
    exit;
} ?>


<div id="tab-content">

    <div class="wrap">

        <div id="surf-sr-redirect-form-notice"></div>
        <div class="surfl-410-grid-wrapper">
            <h2 class="surfl-heading" id="surfl-redirect-3-single-heading">
                <?php esc_html_e('Redirect a post or page', 'surflink'); ?>
            </h2>


            <form id="surfl-redirect-3-form" class="surfl-group">
                <table class="form-table ">
                    <tr>
                        <th scope="row"><?php esc_html_e('Source URL', 'surflink'); ?></th>
                        <td style="display: flex; align-items: center;" class="surfl-redirect-form-td">
                            <label style="background:lightgray;padding: 6px; font-weight: 600;"
                                for="source"><?php echo esc_url(home_url()); ?></label>
                            <input type="text" id="source" class="regular-text" placeholder="/old-page" required>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="font-weight: 400;font-size: 12px; ;color: red;">
                            <?php esc_html_e('If the target url is external, enter the full url', 'surflink'); ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row"><?php esc_html_e('Target URL', 'surflink'); ?></th>
                        <td style="display: flex; align-items: center; flex-direction: column;"
                            class="surfl-redirect-form-td">
                            <div style="display: flex; align-items: center; width: 100%;">
                                <label for="target"
                                    style="background:lightgray;padding: 6px;font-weight: 600;"><?php echo esc_url(home_url()); ?></label>
                                <input type="text" id="target" class="regular-text" placeholder="/new-page">
                            </div>
                            <small class="surfl-responsive-note">
                                <?php esc_html_e("If you want to redirect the URL to your Home URL, leave the Target URL field blank or enter '/'", 'surflink'); ?>
                            </small>
                        </td>
                    </tr>

                    <th scope="row"><?php esc_html_e('Redirect Type', 'surflink'); ?></th>
                    <td>
                        <div class="surfl_redirect_type_options">
                            <label class="surfl_redirect_option">
                                <input type="radio" name="redirect_type" value="301" checked>
                                <span><?php esc_html_e('Permanent Move (301)', 'surflink'); ?></span>
                            </label>
                            <label class="surfl_redirect_option">
                                <input type="radio" name="redirect_type" value="302">
                                <span><?php esc_html_e('Temporary Move (302)', 'surflink'); ?></span>
                            </label>
                            <label class="surfl_redirect_option">
                                <input type="radio" name="redirect_type" value="307">
                                <span><?php esc_html_e('Temporary Redirect (307)', 'surflink'); ?></span>
                            </label>
                        </div>


                    </td>
                    </tr>
                </table>
                <button type="submit" class="button button-primary"
                    id="surfl-submit-redirect-button"><?php esc_html_e('Add Redirect', 'surflink'); ?></button>
            </form>



            <button id="surfl-bulk-redirect-button"
                class="button "><?php esc_html_e('Add Multiple Redirects', 'surflink'); ?></button>

            <!-- Bulk Redirect Form (initially hidden) -->
            <div id="surfl-bulk-redirect-form" class="surfl-group" style="display: none;">
                <h2 class="surfl-heading"><?php esc_html_e('Bulk Add Redirects', 'surflink'); ?></h2>
                <form id="surfl-bulk-redirect-form-inner">
                    <table class="form-table surfl-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Source URLs (one per line)', 'surflink'); ?></th>
                            <td>
                                <textarea id="surfl-bulk-sources" class="large-text code" rows="10" required></textarea>
                                <p class="description">
                                    <?php esc_html_e('Enter one source URL per line. Do not include the domain, only the path (e.g., /old-page)', 'surflink'); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Target URL', 'surflink'); ?></th>
                            <td>
                                <div style="display: flex; align-items: center;">
                                    <label
                                        style="background:lightgray;padding: 6px;font-weight: 600;"><?php echo esc_url(home_url()); ?></label>
                                    <input type="text" id="surfl-bulk-target" class="regular-text" required>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Redirect Type', 'surflink'); ?></th>
                            <td>
                                <div class="surfl_redirect_type_options">
                                    <label class="surfl_redirect_option">
                                        <input type="radio" name="surfl_bulk_redirect_type" value="301" checked>
                                        <span><?php esc_html_e('Permanent Move (301)', 'surflink'); ?></span>
                                    </label>
                                    <label class="surfl_redirect_option">
                                        <input type="radio" name="surfl_bulk_redirect_type" value="302">
                                        <span><?php esc_html_e('Temporary Move (302)', 'surflink'); ?></span>
                                    </label>
                                    <label class="surfl_redirect_option">
                                        <input type="radio" name="surfl_bulk_redirect_type" value="307">
                                        <span><?php esc_html_e('Temporary Redirect (307)', 'surflink'); ?></span>
                                    </label>
                                </div>
                            </td>
                        </tr>
                    </table>
                    <div class="surfl-bulk-redirect-buttons">

                        <button type="button" id="surfl-cancel-bulk"
                            class="button"><?php esc_html_e('Cancel', 'surflink'); ?></button>
                        <button type="submit" id="surfl-bulk-redirect-submit-button"
                            class="button button-primary"><?php esc_html_e('Add Redirects', 'surflink'); ?></button>
                    </div>
                </form>
            </div>
        </div>
        <h2 class="surfl-heading"><?php esc_html_e('Existing Redirects', 'surflink'); ?></h2>

        <div id="surf-sr-redirects-table-notification"></div>
        <!-- Bulk Actions Above the Table -->
        <div class="tablenav top">
            <div class="alignleft actions bulkactions">
                <select name="surfl-redirect-3-bulk_action" id="surfl-redirect-3-bulk_action">
                    <option value="-1"><?php esc_html_e('Bulk Actions', 'surflink'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete', 'surflink'); ?></option>
                    <option value="change_type"><?php esc_html_e('Change Redirect Type', 'surflink'); ?>
                    </option>
                </select>
                <select name="surfl-redirect-3-new-type" id="surfl-redirect-3-new-type" style="display: none;">
                    <option value="301"><?php esc_html_e('301 Permanent', 'surflink'); ?></option>
                    <option value="302"><?php esc_html_e('302 Temporary', 'surflink'); ?></option>
                    <option value="307"><?php esc_html_e('307 Temporary', 'surflink'); ?></option>
                </select>
                <button id="surfl-redirect-3-bulk-action-apply" class="button action">
                    <?php esc_html_e('Apply', 'surflink'); ?>
                </button>
            </div>
            <br class="clear">
        </div>

        <table class="wp-list-table widefat striped surfl-table" style="table-layout:auto;">
            <thead>
                <tr>
                    <th><input type="checkbox" id="surfl-redirect-3-bulk-select-all"></th>
                    <th><?php esc_html_e('ID', 'surflink'); ?></th>
                    <th><?php esc_html_e('Source', 'surflink'); ?></th>
                    <th><?php esc_html_e('Target', 'surflink'); ?></th>
                    <th><?php esc_html_e('Redirect Type', 'surflink'); ?></th>
                    <th><?php esc_html_e('Actions', 'surflink'); ?></th>
                </tr>
            </thead>
            <tbody id="redirect-list">
                <?php foreach ($redirects as $redirect): ?>
                    <tr data-source="<?php echo esc_attr($redirect->source_url); ?>">
                        <td>
                            <input type="checkbox" class="surfl-redirect-3-bulk-select"
                                value="<?php echo esc_attr($redirect->source_url); ?>">
                        </td>
                        <td><?php echo esc_html($redirect->id); ?></td>
                        <td><?php echo esc_html($redirect->source_url); ?></td>
                        <td>
                            <a href="<?php echo esc_url($redirect->target_url); ?>" target="_blank">
                                <?php echo esc_html($redirect->target_url); ?>
                            </a>
                        </td>
                        <td><?php echo esc_html($redirect->redirect_type); ?></td>

                        <td>
                            <button class="edit-redirect"><span class="dashicons dashicons-edit"></span></button>
                            <button class="delete-redirect"><span class="dashicons dashicons-trash"></span></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php echo paginate_links([
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '« Previous',
                        'next_text' => 'Next »',
                        'total' => ceil($total / $per_page),
                        'current' => $current_page
                    ]); ?>
                </div>
            </div>
        </table>
    </div>
</div>